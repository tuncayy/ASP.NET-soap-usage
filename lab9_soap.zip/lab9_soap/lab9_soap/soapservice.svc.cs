﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace lab9_soap
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "soapservice" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select soapservice.svc or soapservice.svc.cs at the Solution Explorer and start debugging.
    public class soapservice : Isoapservice
    {
        public void DoWork()
        {
        }

        public string HelloSOAP()
        {
            return "hello world";
        }

        public string HelloSOAPbyName(string name)
        {
            return "hello" + name;
        }
    }
}
