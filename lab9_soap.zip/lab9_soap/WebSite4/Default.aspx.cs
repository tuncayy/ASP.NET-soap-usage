﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //ServiceReference1.IsoapserviceClient client = new ServiceReference1.IsoapserviceClient();

        //string result = client.HelloSOAP();

        ServiceReference2.GlobalWeatherSoapClient client = new ServiceReference2.GlobalWeatherSoapClient();
        string result = client.GetCitiesByCountry("Turkey");
    }
}